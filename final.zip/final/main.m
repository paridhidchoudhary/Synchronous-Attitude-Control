%main
m=4;
w=0.1;
h=0.1;
d=0.1;

b1=0.3;
b2=0.8;

c1=1; %capacitance of battery of cubesats
c2=1;

%moment of inertias of individual cubesats
i1=(m*(h^2 + d^2)/12)
i2=(m*(h^2 + w^2)/12)
i3=(m*(w^2 + d^2)/12)

%moment of inertia post docking
i11=2*m*(h^2 + d^2)/12
i22=2*m*(h^2 + (2*w)^2)/12
i33=2*m*((2*w)^2 + d^2)/12

% i1= 5;
% i2= 6;
% i3= 7;

%equilibrium points
omega_1=0;
omega_2=0;
omega_3=0;
q1=0;
q2=0;
q3=0;
h1=0;
h2=0;
h3=0;

%state space and gains for individual cubesats
% [A,B]=dynamics(omega_1,omega_2,omega_3,i1,i2,i3,q1,q2,q3,q4,h1,h2,h3)
[A,B]=dynamics_new(omega_1,omega_2,omega_3,q1,q2,q3,i1,i2,i3)
[A_com,B_com]= dynamics_new(omega_1,omega_2,omega_3,q1,q2,q3,i11,i22,i33);
% C=[0 0 0 1 0 0;
%     0 0 0 0 1 0;
%     0 0 0 0 0 1];
% D=zeros(3, 3);
C=eye(length(A));
D=zeros(length(A),3);
% [a_quat b_quat]=linearise_quat(A,B,[q1;q2;q3;q4])
%is_controlable=check_controllability(A,B);
K=control_sys(A,B)
kd=K(:,1:3);
kp=K(:,4:6);

%overall dynamics
[A_ext,B_ext]= dynamics_ext(i1,i2,i3,i1,i2,i3,i11,i22,i33,q1,q2,q3,q1,q2,q3,q1,q2,q3,omega_1,omega_2,omega_3,omega_1,omega_2,omega_3,omega_1,omega_2,omega_3,c1,c2)
n_states=20;
n_inputs=6;
C_ext=eye(n_states);
D_ext=zeros(n_states,n_inputs);

%MPC
sys= ss(A_ext, B_ext, C_ext, D_ext);
Ts=1;
sys_d= c2d(sys,Ts);
sys_minimal= minreal(sys_d);
mpcobj= mpc(sys_minimal,Ts);
mpcobj.Model.Noise=[];


%prediction and control horizons
mpcobj.PredictionHorizon= 10;
mpcobj.ControlHorizon =3;

% %define output variables and manipulated variables
% mpcobj.OutputVariables =[1:20];
% mpcobj.ManipulatedVariables= [1:6];

%Manipulated Variables (Control Inputs) Constraints
for i=1:6
    mpcobj.ManipulatedVariables(i).Min=-0.1;
    mpcobj.ManipulatedVariables(i).Max=0.1;
end

%Output Variables Constraints
%Angular Velocity
for i=[1:3,7:9,13:15]
    mpcobj.OutputVariables(i).min=-pi/4;
    mpcobj.OutputVariables(i).max= pi/4;
end

%Quaternions constraints (Normalisation is handled outside mpc)
for i=[4:6,10:12,16:18]
    mpcobj.OutputVariables(i).min=-1;
    mpcobj.OutputVariables(i).max=1;
end

%battery constraints
for i=(19:20)
    mpcobj.OutputVariables(i).min=0.1;
    mpcobj.OutputVariables(i).max=1;
end

%weights
% mpcobj.Weights.OutputVariables=[10*ones(1,3), ones(1,3), 10*ones(1,3), ones(1,3), 10*ones(1,3), ones(1,3),100,100];
% mpcobj.Weights.ManipulatedVariables= ones(1,6);
% mpcobj.Weights.ManipulatedVariablesRate= 0.1*ones(1,6);

%scale factors
% mpcobj.Model.Nominal.Y= [pi/4*ones(1,3), ones(1,3), pi/4*ones(1,3), ones(1,3), pi/4*ones(1,3), ones(1,3), 0.5, 0.5];
% mpcobj.Model.Nominal.U= 0.1*ones(1,6);
% mpcobj.Model.Nominal.X= mpcobj.Model.Nominal.Y;

%custom constraints
% mpcobj.= @(X,U) customConstraints(X,U);
% setconstraint(mpcobj)
%custom cost function: add penalty for low battery
Optimization.CustomCostFcn= @(X,U,e,data,params) customCost(X,U,e,data,params);

review(mpcobj);

function[c,ceq]= customConstraints(X,U)
b1=X(19,:);
b2=X(20,:);

omega1=X(1:3,:);
omega2=X(7:9,:);

P1=sum(U(1:3,:).*omega1);
P2=sum(U(4:6,:).*omega2);

c1= P1- 2*b1; %P1<=2*b1
c2= P2- 2*b2;

c=[c1;c2];
ceq=[];
end

function J=customCost(X,U,e,data,params)
Q= [10*ones(1,3), ones(1,3), 10*ones(1,3), ones(1,3), 10*ones(1,3), ones(1,3),100,100];
R= diag([1 1 1 1 1 1]);
b1=X(end-1,:);
b2=X(end,:);
R_battery= diag([1./b1(1) 1./b1(1) 1./b1(1) 1./b2(1) 1./b2(1) 1./b2(1)]);

J=0;
for k=1:size(X,2)
    J= J+ X(:,k)'*Q*X(:,k) + U(:,k)'*(R + R_battery)*U(:,k);
end

%penalties for attitude differences
for k=1:size(X,2)
    q_sys=zeros(4,1);
    q_sys(1:3)= X(16:18,k);
    q_sys(4)= sqrt(1-X(16,k)^2-X(17,k)^2-X(18,k)^2);

    q_1=zeros(4,1);
    q_1(1:3)= X(4:6,k);
    q_1(4)= sqrt(1-X(4,k)^2-X(5,k)^2-X(6,k)^2);

    q_2=zeros(4,1);
    q_2(1:3)= X(10:12,k);
    q_2(4)= sqrt(1-X(10,k)^2-X(11,k)^2-X(12,k)^2);
    J= J+ 100*norm(qerr(q_sys,q_1))^2 + 100*norm(qerr(q_sys,q_2))^2 +100*(qerr(q_1,q_2))^2;
end
end






