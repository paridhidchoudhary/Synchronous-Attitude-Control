function b_next=battery(x1,x2,u1,u2,c1,c2,dt,b_prev)

omega1=x1(1:3);
omega2=x2(1:3);
p_1= u1(1)*omega1(1) + u1(2)*omega1(2) + u1(3)*omega1(3);
p_2= u2(1)*omega2(1) + u2(2)*omega2(2) + u2(3)*omega2(3);

dbdt1= -p_1/c1;
dbdt2= -p_2/c2;
b_dot=[dbdt1; dbdt2];
b_next= b_prev+ dt*b_dot;

end
