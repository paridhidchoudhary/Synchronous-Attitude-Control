function [state_dot] = satellite(state, I, tau)
% 3DOF dynamical equation

  w = state(1:3);
  q = state(4:7);

  w_dot = kinetics(w, I, tau);
  q_dot = kinematics(q, w);

  state_dot = [w_dot; q_dot];
end

% Euler's equation of rotational dynamics
function [w_dot] = kinetics(w, I, tau)
  w_dot = I \ (-cross(w, I * w) + tau);
end

% Quaternion kinematics differential equation
function [q_dot] = kinematics(q, w)
  Xi = [q(4) * eye(3) + hat(q(1:3)); -q(1:3)']; % Eqn(A.9b)
  % Xi = [q0 * eye(3) + skew(q(1:3))];
  q_dot = 0.5 * Xi * w; % Eqn(A.51)
  
end
