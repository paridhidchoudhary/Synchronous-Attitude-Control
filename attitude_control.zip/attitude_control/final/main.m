%main
clc
clear
close all

start_time = 0;
stop_time = 20;
dt = 1;
time = start_time : dt : stop_time;

%physical parameters of individual satellites
m=4;
w=0.1;
h=0.1;
d=0.1;

%battery levels and capacitance of satellites
b1=0.3;
b2=0.8;
c1=1; 
c2=1;

%moment of inertias of individual cubesats
I = [(m*(h^2 + d^2)/12), 0, 0; 0, (m*(h^2 + w^2)/12), 0; 0, 0, (m*(w^2 + d^2)/12)];
I_sys= [2*m*(h^2 + d^2)/12, 0, 0; 0, 2*m*(h^2 + (2*w)^2)/12, 0; 0, 0, 2*m*((2*w)^2 + d^2)/12];

% Initiaizations
w0 = deg2rad([5,5,1]'); % Angular rate, rad/s
q0 = [0.5,0.5,0.5,0.5]'; % Quaternion
qd = [0, 0, 0, 1]'; % Desired quaternion


%Non Linear MPC
n_x=23;
n_y=23;
n_u=6;
%non linear mpc object
nlobj= nlmpc(n_x,n_y, n_u);
%sample time 
Ts= 0.25;
p=10;
m=5;
nlobj.PredictionHorizon= p;
nlobj.ControlHorizon =m;
nlobj.Ts= Ts;
%state function and output fcn
nlobj.Model.StateFcn= @(x,u) stateFcn_discrete_rk4(x,u,I,I_sys,c1,c2,Ts);
nlobj.Model.OutputFcn= @(x,u) outputFcn(x,u);

validateFcns(nlobj,rand(n_x,1),rand(n_u,1));

%Manipulated Variables (Control Inputs) Constraints
% nlobj.MV = struct( ...
%     Min={0;0;0;0;0;0}, ...
%     Max={10;10;10;10;10;10}, ...
%     RateMin={-2;-2;-2;-2;-2;-2}, ...
%     RateMax={2;2;2;2;2;2} ...
%     );
% for i=1:6
%     nlobj.ManipulatedVariables(i).Min=-0.5;
%     nlobj.ManipulatedVariables(i).Max=0.5;
% end

%Output Variables Constraints
%Angular Velocity
for i=[1:3,8:10,15:17]
    nlobj.OutputVariables(i).Min=-pi/2;
    nlobj.OutputVariables(i).Max= pi/2;
end

%Quaternions constraints (Normalisation is handled outside mpc)
for i=[4:7,11:14,18:21]
    nlobj.OutputVariables(i).Min=-1;
    nlobj.OutputVariables(i).Max=1;
end

%battery constraints
nlobj.OutputVariables(22).Min=0.1;
nlobj.OutputVariables(22).Max=1;
nlobj.OutputVariables(23).Min=0.1;
nlobj.OutputVariables(23).Max=1;


%initial state
x0= [deg2rad([5, 5, 1]) ,[0.5, 0.5, 0.5, 0.5], deg2rad([5, 5, 1]), [0.5, 0.5, 0.5, 0.5], deg2rad([5,5,1]), [0.5,0.5,0.5,0.5], b1, b2];
u0= [0.1 0.1 0.1 0.1 0.1 0.1];
yref= zeros(23,1);
yref(7)=1;
yref(14)=1;
yref(21)=1;
yref(22)=0.1;
yref(23)=0.1;
disp(yref');
disp(x0);

nlobj.Optimization.CustomCostFcn= @(X,U,e,data) customCost(X,U,e,data,yref');

%simulation options
nloptions= nlmpcmoveopt;

% Memory allocation
state1 = zeros(7, length(time)); %angular velocity and attitude of 1st cubesat
tau1 = zeros(3, length(time));
dq1 = zeros(4, length(time));
state1(:,1) = [w0; q0];

state2 = zeros(7, length(time));
tau2 = zeros(3, length(time));
dq2 = zeros(4, length(time));
state2(:,1) = [w0; q0];

state3 = zeros(7, length(time));
dq3 = zeros(4, length(time));
state3(:,1) = [w0; q0];

state4=zeros(2,length(time));
state4(:,1)=[b1;b2];
num_steps=2;

for k=1:length(time)-1
    try
      [u,info]= nlmpcmove(nlobj,x0,u0,yref',[],nloptions);
      u0=u';
      disp(u);    
      
      tau1(:,k)= u(1:3);
      tau2(:,k)= u(4:6);
      disp(['tau1: ', num2str(tau1(:,k)')]);
      disp(['tau2: ', num2str(tau2(:,k)')]);
      
      % Numerical integration
      fn1 = @(state1)satellite(state1, I, tau1(:,k));
      state1(:,k+1) = rk4(fn1, state1(:,k), dt);
      fn2 = @(state2)satellite(state2, I, tau2(:,k));
      state2(:,k+1) = rk4(fn2, state2(:,k), dt);
      fn3 = @(state3)satellite(state3, I_sys,tau1(:,k)+ tau2(:,k));
      state3(:,k+1) = rk4(fn3, state3(:,k), dt);
      state4(:,k+1)= battery(state1(:,k),state2(:,k),tau1(:,k),tau2(:,k),c1,c2,dt,state4(:,k));
    
      % Quaternion normalization
      state1(4:7,k+1) = state1(4:7,k+1) / norm(state1(4:7,k+1));
      state2(4:7,k+1) = state2(4:7,k+1) / norm(state2(4:7,k+1));
      state3(4:7,k+1) = state3(4:7,k+1) / norm(state3(4:7,k+1));
    
      x0=[state1(:,k+1)', state2(:,k+1)', state3(:,k+1)', state4(:,k+1)']

    catch ME
        disp('Error occured:');
        disp(getReport(ME));
        break;
    end
end

dq1(:,end) = qerr(qd, state1(4:7,end));
dq2(:,end) = qerr(qd, state1(4:7,end));

figure;
subplot(4,1,1);
plot(time,state1(4,:),'LineWidth',2);grid on;
title('Cubesat1 attitude profile');
ylabel('q1'); subplot(4,1,2);
plot(time,state1(5,:),'LineWidth',2);grid on;
ylabel('q2'); subplot(4,1,3);
plot(time,state1(6,:),'LineWidth',2);grid on;
ylabel('q3'); subplot(4,1,4);
plot(time,state1(7,:),'LineWidth',2);grid on;
ylabel('q4');

figure;
subplot(4,1,1);
plot(time,state2(4,:),'LineWidth',2);grid on;
title('Cubesat2 attitude profile');
ylabel('q1'); subplot(4,1,2);
plot(time,state2(5,:),'LineWidth',2);grid on;
ylabel('q2'); subplot(4,1,3);
plot(time,state2(6,:),'LineWidth',2);grid on;
ylabel('q3'); subplot(4,1,4);
plot(time,state2(7,:),'LineWidth',2);grid on;
ylabel('q4');

figure;
subplot(3,1,1);
plot(time,state1(1,:),'LineWidth',2);grid on;
title('Cubesat1 torque profile');
ylabel('u1'); subplot(3,1,2);
plot(time,state1(2,:),'LineWidth',2);grid on;
ylabel('u2'); subplot(3,1,3);
plot(time,state1(3,:),'LineWidth',2);grid on;
ylabel('u3');

figure;
subplot(3,1,1);
plot(time,state2(1,:),'LineWidth',2);grid on;
title('Cubesat2 torque profile');
ylabel('u1'); subplot(3,1,2);
plot(time,state2(2,:),'LineWidth',2);grid on;
ylabel('u2'); subplot(3,1,3);
plot(time,state2(3,:),'LineWidth',2);grid on;
ylabel('u3');


function J=customCost(X,U,e,data,yref)
%Q= diag([10*ones(1,3), ones(1,4), 10*ones(1,3), ones(1,4), 10*ones(1,4), ones(1,4),100,100]);
Q=1000*eye(23);
R= 0.1*diag([1 1 1 1 1 1]);
b1=max(X(:,end-1),0.1);
b2=max(X(:,end),0.1);
R_battery= diag([1./b1(1) 1./b1(1) 1./b1(1) 1./b2(1) 1./b2(1) 1./b2(1)]);

J=0;
p=data.PredictionHorizon;
% for k=1:size(X,1)
%     J= J+ (X(k,:))*Q*(X(k,:))' + U(k,:)*(R + R_battery)*U(k,:)';
% end

for k=2:p+1
    q_1= X(k,4:7) /norm(X(k,4:7));
    q_2= X(k,11:14)/norm(X(k,11:14)) ;
    q_sys= X(k,18:21) /norm(X(k,18:21)) ;
    qd=yref(4:7) ;
    dq1=qerr(qd',q_1')';
    dq2=qerr(qd',q_2')';
    dq3=qerr(qd',q_sys')';
    dx=[X(k,1:3)-yref(1:3), dq1, X(k,8:10)-yref(8:10), dq2, X(k,15:17)-yref(15:17), dq3, X(k,22:23)-yref(22:23)];
    J= J+ (dx)*Q*(dx)';
end
for k=1:p
    J=J+ U(k,:)*(R + R_battery)*U(k,:)';
end

%penalties for attitude differences
for k=2:p+1
    q_1= X(k,4:7);
    q_2= X(k,11:14);
    q_sys= X(k,18:21);
    J= J+ 100*(norm(qerr(q_sys',q_1')))^2 + 100*(norm(qerr(q_sys',q_2')))^2 +100*(norm(qerr(q_1',q_2')))^2;
end
end






