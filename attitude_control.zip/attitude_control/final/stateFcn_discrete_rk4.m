function x_next= stateFcn_discrete_rk4(x,u,I,I_sys,c1,c2,Ts)
try
     k1 = Ts * stateFcn_cont(x, u, I, I_sys, c1, c2);
     k2 = Ts * stateFcn_cont(x + 0.5 * k1, u, I, I_sys, c1, c2);
     k3 = Ts * stateFcn_cont(x + 0.5 * k2, u, I, I_sys, c1, c2);
     k4 = Ts * stateFcn_cont(x + k3, u, I, I_sys, c1, c2);
        
     % Compute the next state
     x_next = x + (1/6) * (k1 + 2*k2 + 2*k3 + k4);
    
     %normalisation of quaternions:
     x_next(4:7)= x_next(4:7) / norm(x_next(4:7));
     x_next(11:14)= x_next(11:14) / norm( x_next(11:14));
     x_next(18:21)= x_next(18:21) / norm(x_next(18:21));
catch ME
    disp('Error in stateFcn_discrete_rk4:');
    disp(['x = ', mat2str(x)]);
    disp(['u = ', mat2str(u)]);
    disp(getReport(ME));
    x_next=x;
end
end

function x_dot=stateFcn_cont(x,u,I,I_sys,c1,c2)
x1=x(1:7);
x2=x(7:14);
x_tot= x(14:21);
b1=x(22);
b2=x(23);
u1=u(1:3);
u2=u(4:6);
u3= u1+ u2;
omega1=x1(1:3);
omega2=x2(1:3);


x1_dot= satellite(x1,I,u1);
x2_dot= satellite(x2,I,u2);
xtot_dot= satellite(x_tot,I_sys,u3);

p_1= u1(1)*omega1(1) + u1(2)*omega1(2) + u1(3)*omega1(3);
p_2= u2(1)*omega2(1) + u2(2)*omega2(2) + u2(3)*omega2(3);

dbdt1= -p_1/c1;
dbdt2= -p_2/c2;

x_dot= [x1_dot;x2_dot;xtot_dot;dbdt1;dbdt2];
end
