%main
clc
clear
close all

start_time = 0;
stop_time = 20;
dt = 1;
time = start_time : dt : stop_time;

%physical parameters of individual satellites
m=4;
w=0.1;
h=0.1;
d=0.1;

%moment of inertias of individual cubesats
I = [(m*(h^2 + d^2)/12), 0, 0; 0, (m*(h^2 + w^2)/12), 0; 0, 0, (m*(w^2 + d^2)/12)];
I_sys= [2*m*(h^2 + d^2)/12, 0, 0; 0, 2*m*(h^2 + (2*w)^2)/12, 0; 0, 0, 2*m*((2*w)^2 + d^2)/12];

% Initiaizations
w0 = deg2rad([5,5,1]'); % Angular rate, rad/s
q0 = [0.5,0.5,0.5,0.5]'; % Quaternion
qd = [0, 0, 0, 1]'; % Desired quaternion

%battery levels and capacitance of satellites
b1=0.3;
b2=0.8;
c1=1; 
c2=1;

[A,B]=dynamics_new(0,0,0,qd(1),qd(2),qd(3),I(1,1),I(2,2),I(3,3));

k=control_sys(A,B)
C=eye(length(A));
D=zeros(length(A),3);
kd=k(:,1:3);
kp=k(:,4:6);

%overall dynamics
[A_ext,B_ext]= dynamics_ext(I(1,1),I(2,2),I(3,3),I(1,1),I(2,2),I(3,3),I_sys(1,1),I_sys(2,2),I_sys(3,3),qd(1),qd(2),qd(3),qd(1),qd(2),qd(3),qd(1),qd(2),qd(3),0,0,0,0,0,0,0,0,0,c1,c2);
n_states=23;
n_inputs=6;
C_ext=eye(n_states);
D_ext=zeros(n_states,n_inputs);
k_sys=control_sys(A_ext,B_ext);
kd=k_sys(:,1:3);
kp=k_sys(:,4:6);