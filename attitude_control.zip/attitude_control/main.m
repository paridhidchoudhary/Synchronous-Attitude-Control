[b_1,b_2,r_1,r_2,r_max1,r_max2,r_min1,r_min2,t_1,t_2,t_max1,t_max2,t_min1,t_min2,alpha_expected1,alpha_expected2,alpha_1,alpha_2,wb,wr,wt,we]=params();
%health index
R1=normalise(r_1,r_max1,r_min1);
R2=normalise(r_2,r_max2,r_min2);
t1=normalise(t_1,t_max1,t_min1);
t2=normalise(t_2,t_max2,t_min2);
[e1,e2]=effectiveness(alpha_expected1,alpha_expected2,alpha_1,alpha_2);
E1=[e1(1,1);e1(2,1);e1(3,1)];
E2=[e2(1,3);e2(2,3);e2(3,3)];
% we*E1

h_1=wb*(b_1)+ wr*(1-R1)+ wt*(1-t1) + we*E1,
h_2=wb*(b_2)+ wr*(1-R2)+ wt*(1-t2) + we*E2;

% hr1=wb(b_1)+ wr(1-R1)+ wt(1-t1);
% hr2=wb(b_2)+ wr(1-R2)+ wt(1-t2);
% he11=we*(e1(1,1));
% he12=we*(e1(2,1));
% he13=we*(e1(3,1));
% he21=we*(e2(1,3));
% he22=we*(e1(2,3));
% he23=we*(e1(3,3));



%weights 
w1=(h_1)/(h_2+h_1)
w2=(h_2)/(h_2+h_1)

