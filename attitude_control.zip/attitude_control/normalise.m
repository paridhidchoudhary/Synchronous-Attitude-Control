function t=normalise(t_actual,t_max,t_min)
    t=(t_actual-t_min)/(t_max-t_min);
end