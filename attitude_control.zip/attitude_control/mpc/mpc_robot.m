addpath('C:\Users\Floatsat\Downloads\casadi-3.6.5-windows64-matlab2018b');
import casadi.*

T=0.2;
N=3;
rib_dia=0.3;

v_max=0.6; v_min=-v_max;
omega_max=pi/4; omega_min=-omega_max;

x=SX.sym('x');
y=SX.sym('y');
theta=SX.sym('theta');
states=[x;y;theta]; n_states=length(states);

v=SX.sym('v');
omega=SX.sym('omega');
controls=[v;omega]; n_controls=length(controls);

rhs=[v*cos(theta);v*sin(theta); omega];

f=Function('f',{states,controls},{rhs}); %function block of casadi
U=SX.sym('U',n_controls,N) %2 rows, 3 colums matrix, is column: u1, u2 or
%  v1 omega 1, and so on for all the timesteps
P=SX.sym('P',n_states+n_states);
%parameters include initial values and desired values of each state, hence
%twice no of rows as n_states since it stores 2 values: initial and desired
%state for each state
%P=[p0, p1, p2, p3, p4, p5, p6]
%p0=initial va;ue of first state, p1=initial value of second state,
%p2=intial value of third state, p3=desired value of first stae and so on
X=SX.sym('X',n_states,(N+1));
%matrix storing all the predicted value of states over the optimisation problem
%row: state, column: time
X(:,1)=P(1:3); % first three values are the initial values of the states in P

for k=1:N
    st=X(:,k);
    f_value=f(st,U(:,k));
    next_st=st+T*(f_value);
    X(:,k+1)=next_st;
end

%function to predict the values
ff=Function('ff',{U,P},{X});

%objective function
obj=0;
g=[];

q=zeros(3,3); q(1,1)=1; q(2,2)=5; q(3,3)=0.1;
r=zeros(2,2); r(1,1)=0.5; r(2,2)=0.05;
%objective function computation, similar to lqr
for k=1:N
    st=X(:,k); con=U(:,k);
    obj= obj+ (st-P(4:6))'*q*(st-P(4:6)) + con'*r*con;
end

%constraints computation
%for a robot, the constraints would be that we want the robot to stay in
%the given area, so constraints would be x and y values from the predicted
%states
for k=1:N+1
    g= [g; X(1,k)]; %state x
    g= [g; X(2,k)]; %state y
end

OPT_variables= reshape(U, 2*N, 1)
nlp_prob = struct('f', obj, 'x', OPT_variables, 'g', g, 'p', P);
opts=struct;
%ipopt is an open source software package mainly used fopr non linear
%optimisation
opts.ipopt.max_iter=1000;
opts.ipopt.print_level=3;
opts.print_time=0;
opts.ipopt.acceptable_tol=1e-8;
%optimality convergence tolerance
opts.ipopt.acceptable_obj_change_tol=1e-6;

solver=nlpsol('solver','ipopt', nlp_prob, opts);

args=struct;
args.lbg=-2; % lower bounds of the states x and y
args.ubg= 2; %upper bounds of the states x and y

args.lbx(1:2:2*N-1, 1)=v_min; args.lbx(2:2:2*N, 1)= omega_min;
args.ubx(1:2:2*N-1, 1)=v_max; args.ubx(2:2:2*N, 1)= v_min;


%%%main simulation loop
t0=0;
x0=[0; 0; 0]; %initial values of states
xs=[1.5; 1.5; 0.0]; %reference values of the states
xx(:,1)= x0; %xx stores the hsitory of the state values , initially at 0th
%  timestep, the value of states is the initial value, hence it is sored in
%  first column

t(1)=t0; %t stores timesteps
u0=zeros(N,2); %two control inputs
sim_tim=20;
%start mpc
mpciter=0;
xx1=[];
u_cl=[];
norm((x0-xs),2)

while (norm((x0-xs),2) > 1e-2 && mpciter< (sim_tim/ T))
    args.p= [x0; xs];
    args.x0= reshape(u0', 2*N, 1); %initial value of optimisation variables
    sol=solver('x0',args.x0,'lbx',args.lbx, 'ubx', args.ubx, 'lbg', args.lbg, 'ubg', args.ubg);
    u=reshape(full(sol.x)',2,N)'
    ff_value=ff(u',args.p);
    xx1(:,1:3,mpciter+1)=full(ff_value)'
    u_cl=[u_cl;u(1,:)]; %we only take the control action at the very next timestep

    t(mpciter+1)= t0;
    [t0, x0, u0]= shift(T,t0,x0,u,f);
    xx(:, mpciter+2)=x0;
    mpciter= mpciter+1;
end


    



 









