function [t0,x0,u0]= shift(T,t0,x0,u, f)
st=x0;
con=u(1,:);
st=st+ T*(f(x0,con));
x0=full(st);
t0=t0+T;
u0=[u(2:size(u,1),:); u(size(u:1),:)];
end