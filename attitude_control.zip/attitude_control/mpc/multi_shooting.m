addpath('C:\Users\Floatsat\Downloads\casadi-3.6.5-windows64-matlab2018b');
import casadi.*

T=0.2;
N=3;
rib_dia=0.3;

v_max=0.6; v_min=-v_max;
omega_max=pi/4; omega_min=-omega_max;

x=SX.sym('x');
y=SX.sym('y');
theta=SX.sym('theta');
states=[x;y;theta]; n_states=length(states);

v=SX.sym('v');
omega=SX.sym('omega');
controls=[v;omega]; n_controls=length(controls);

rhs=[v*cos(theta);v*sin(theta); omega];

f=Function('f',{states,controls},{rhs}); %function block of casadi
U=SX.sym('U',n_controls,N) %2 rows, 3 colums matrix, is column: u1, u2 or
%  v1 omega 1, and so on for all the timesteps
P=SX.sym('P',n_states+n_states);
%parameters include initial values and desired values of each state, hence
%twice no of rows as n_states since it stores 2 values: initial and desired
%state for each state
%P=[p0, p1, p2, p3, p4, p5, p6]
%p0=initial va;ue of first state, p1=initial value of second state,
%p2=intial value of third state, p3=desired value of first stae and so on
X=SX.sym('X',n_states,(N+1));
%matrix storing all the predicted value of states over the optimisation problem
%row: state, column: time

%function to predict the values
ff=Function('ff',{U,P},{X});

%objective function
obj=0;
g=[];

q=zeros(3,3); q(1,1)=1; q(2,2)=5; q(3,3)=0.1;
r=zeros(2,2); r(1,1)=0.5; r(2,2)=0.05;
%objective function computation, similar to lqr
st = X(:,1);
g = [g;st-P(1:3)];
for k=1:N
    st=X(:,k);
    con=U(:,k);
    next_st=X(:,k+1);
    f_value=f(st,con);
    next_st_pred=st+ T*(f_value);
    g=[g;next_st-next_st_pred];
end

%begin optimisation
opt_variables=[reshape(X,3*(N+1),1); reshape(U,2*N,1)];

nlp_prob= struct('f', obj, 'x', opt_variables, 'g', g, 'p', P);
opts=struct;
%ipopt is an open source software package mainly used fopr non linear
%optimisation
opts.ipopt.max_iter=1000;
opts.ipopt.print_level=3;
opts.print_time=0;
opts.ipopt.acceptable_tol=1e-8;
%optimality convergence tolerance
opts.ipopt.acceptable_obj_change_tol=1e-6;

solver=nlpsol('solver','ipopt', nlp_prob, opts);
% here g is g2 which is x-f and we want it to 0, so upper and lowert bounds
% of g has to be 0
%no of states =3

args=struct;
args.lbg(1:3*(N+1))=0;
args.ubg(1:3*(N_1))=0;

args.lbx(1:3:3*(N+1),1)=-2; %lower bound of x
args.ubx(1:3:3*(N+1),1)=2;  %upper bound of x
args.lbx(2:3:3*(N+1),1)=-2; %lower bound of y
args.ubx(2:3:3*(N+1),1)=2;  %upper bound of y
args.lbx(3:3:3*(N+1),1)=-inf; %lower bound of theta
args.ubx(3:3:3*(N+1),1)=inf; %upper bound of theta

args.lbx(3*(N+1)+1:2:3*(N+1)+2*N,1)=v_min; %lower bound of v
args.ubx(3*(N+1)+1:2:3*(N+1)+2*N,1)=v_max; %upper bound of v
args.lbx(3*(N+1)+2:2:3*(N+1)+2*N,1)=omega_min; %lower bound of omega
args.ubx(3*(N+1)+2:2:3*(N+1)+2*N,1)=omega_max; %upper bound of omega

%simulation loop
t0=0;
x0=[0;0;0.0];
xs=[1.5;1.5;0.0];

xx(:,1)=x0;
t(1)=t0;
u0= zeros(N,2); %2 control inputs
X0= repmat(x0,1,N+1)'; %repmat(x0,1,N+1) gives 3*N+1 matrix, its transpose 
% gives N+1*3 matrix
sim_time=20; %maximum simulation time

%start mpcv
mpc_iter=0; xx1=[]; u_cl=[];







