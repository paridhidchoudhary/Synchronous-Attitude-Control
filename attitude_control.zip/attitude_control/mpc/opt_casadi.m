addpath('C:\Users\Floatsat\Downloads\casadi-3.6.5-windows64-matlab2018b');
import casadi.*

x=SX.sym('w'); %decision variables
%SX is a basic data type used in casadi that represents matrices whose
%elements consits of symbolic expressions
obj=x^2 - 6*x +13;
% another objective function: 
obj_2= exp(0.2*x).*sin(x);

g=[]; %constraints , empty currently
P=[]; %optimisation problem paramters, empty currently

OPT_variables=x; %single decision variable
nlp_prob= struct('f',obj_2,'x',OPT_variables,'g',g,'p',P)

opts=struct;
%ipopt is an open source software package mainly used fopr non linear
%optimisation
opts.ipopt.max_iter=1000;
opts.ipopt.print_level=3;
opts.print_time=0;
opts.ipopt.acceptable_tol=1e-8;
%optimality convergence tolerance
opts.ipopt.acceptable_obj_change_tol=1e-6;

%solver is an object of nlpsol class
solver=nlpsol('solver','ipopt',nlp_prob,opts);

%in casadi, optimisation problems are structured in the following way: 
%optimise x for min f(x,p) with respect to x0<x<xf and g0<g(x,p)<gf
% specify lower bounds and upper bounds of x and g

args=struct;
args.lbx=0;
args.ubx=4*pi;
args.lbg=-inf;
args.ubg=inf;

%no parameters(p)
args.p=[];
args.x0=4; %initialisation of optimisation

sol=solver('x0',args.x0,'lbx',args.lbx,'ubx',args.ubx,'lbg',args.lbg,'ubg',args.ubg,'p',args.p);
x_sol=full(sol.x)
min_value=full(sol.f)



