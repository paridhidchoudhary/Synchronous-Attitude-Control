addpath('C:\Users\Floatsat\Downloads\casadi-3.6.5-windows64-matlab2018b');
import casadi.*

x=[0,45,90,135,180];
y=[667,661,757,871,1210];

figure(1)
plot(x,y,'*b');hold
xlabel('x')
ylabel('y')
grid on

m=SX.sym('m');
c=SX.sym('c');
obj=0;
for i=1:length(x)
    obj= obj+(y(i)-(m*x(i)+c))^2;
end

g=[];
P=[];

OPT_variables=[m,c];
nlp_prob=struct('f',obj,'x',OPT_variables,'g',g,'p',P);

opts=struct;
%ipopt is an open source software package mainly used fopr non linear
%optimisation
opts.ipopt.max_iter=1000;
opts.ipopt.print_level=3;
opts.print_time=0;
opts.ipopt.acceptable_tol=1e-8;
%optimality convergence tolerance
opts.ipopt.acceptable_obj_change_tol=1e-6;

solver=nlpsol('solver','ipopt',nlp_prob,opts);

arg=struct;
arg.lbx=-inf;
arg.ubx=inf;
arg.lbg=-inf;
arg.ubg=inf;
arg.x0=[0.5,1];
arg.p=[];

sol=solver('x0',arg.x0,'lbx',arg.lbx,'ubx',arg.ubx,'lbg',arg.lbg,'ubg',arg.ubg,'p',arg.p);
x_sol=full(sol.x)
min_value=full(sol.f)

m_sol=x_sol(1)
c_sol=x_sol(2)
x_line=[0:1:180];
y_line=m_sol*x_line+c_sol;
plot(x_line,y_line)



