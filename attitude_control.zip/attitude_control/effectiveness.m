function [e_1 , e_2] =effectiveness(alpha_expected1,alpha_expected2,alpha_1,alpha_2)
    e_1= abs(alpha_1)/abs(alpha_expected1);
    e_2= abs(alpha_2)/abs(alpha_expected2);
end