mu=398600.4418E9;
r=6378.14E3 + 500E3;

%battery levels of cubesats
b1=0.3;
b2=0.8;

% assuming identical cubesats, physical parameters
m=4;
w=0.3;
h=0.1;
d=0.1;

