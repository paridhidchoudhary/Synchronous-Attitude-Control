function [b_1,b_2,r_1,r_2,r_max1,r_max2,r_min1,r_min2,t_1,t_2,t_max1,t_max2,t_min1,t_min2,alpha_expected1,alpha_expected2,alpha_1,alpha_2,wb,wr,wt,we]=params()
    b_1= 0.2; %battery level of cubesat 1
    b_2= 0.6; %battery level of cubesat 2

    r_1= 20; %reaction wheel speed of cubesat 1
    r_2= 60; %reaction wheel speed of cubesat 2
    r_max1= 100;
    r_min1= 0;
    r_max2= 100;
    r_min2= 0;
   
   
    t_1= 30; %temp of cubesat1
    t_2= 40; %temp of cubesat2
    t_max1=500;
    t_min1=20;
    t_max2=500;
    t_min2=20;
    
    

    %moment of inertia
    I_1= [0.5 0 0; 0 0.5 0; 0 0 0.5];
    tau_1= [10;10;10];
    alpha_expected1= inv(I_1)*tau_1
    alpha_1=[21;22;20.5];

    I_2= [1 0 0; 0 1 0; 0 0 1];
    tau_2= [20;10;30];
    alpha_expected2= inv(I_2)*tau_2
    alpha_2=[21;10;25];

    %weights
    wb=1;
    wr=1;
    wt=1;
    we=[1 1 1];

end